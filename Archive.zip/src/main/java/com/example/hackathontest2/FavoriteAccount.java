package com.example.hackathontest2;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.NotBlank;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FavoriteAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long id;

    @NotBlank
    @Pattern(regexp = "^[0-9a-zA-Z'\\- ]*")
    public String accountName;

    @NotBlank @Pattern(regexp = "^( *[0-9a-zA-Z]? *){1,20}$")
    public String iban;

    @NotBlank
    public String bank;

}
