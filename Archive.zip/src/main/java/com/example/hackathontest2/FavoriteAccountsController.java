package com.example.hackathontest2;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("/favorite-accounts")
@Slf4j
@RequiredArgsConstructor
public class FavoriteAccountsController {

    private final FavoriteAccountRepository favoriteAccountRepository;

    @GetMapping
    public Iterable<FavoriteAccount> listFavoriteAccounts() {
        return favoriteAccountRepository.findAll();
    }

    @GetMapping("/{id}")
    public Optional<FavoriteAccount> getFavoriteAccount(@PathVariable("id") Long id) {
        return favoriteAccountRepository.findById(id);
    }

    @PostMapping
    public FavoriteAccount createFavoriteAccount(@Valid @RequestBody FavoriteAccount favoriteAccount) {
        favoriteAccount.id = null;
        return favoriteAccountRepository.save(favoriteAccount);
    }

    @PutMapping("/{id}")
    public FavoriteAccount editFavoriteAccount(@PathVariable("id") long id, @Valid @RequestBody FavoriteAccount favoriteAccount) {
        favoriteAccount.id = id;
        return favoriteAccountRepository.save(favoriteAccount);
    }

    @DeleteMapping("/{id}")
    public void createFavoriteAccount(@PathVariable("id") long id) {
        favoriteAccountRepository.deleteById(id);
    }

}
