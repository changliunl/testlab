package com.example.hackathontest2;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@RunWith(SpringRunner.class)
@SpringBootTest(
        webEnvironment = SpringBootTest.WebEnvironment.MOCK,
        classes = Hackathontest2Application.class)
public class FavoriteAccountsControllerTest {

    @MockBean
    private FavoriteAccountRepository repository;

    private FavoriteAccountsController controller;

    @Before
    public void init() {
        controller = new FavoriteAccountsController(repository);
    }

    @Test
    public void test_getFavoriteAccounts() {

        FavoriteAccount favoriteAccount = FavoriteAccount.builder()
                .id(0L)
                .accountName("Test")
                .iban("Test")
                .bank("Test")
                .build();

        List<FavoriteAccount> favoriteAccounts = Arrays.asList(favoriteAccount);

        Mockito.when(repository.findAll()).thenReturn(favoriteAccounts);

        assertThat(controller.listFavoriteAccounts()).isEqualTo(favoriteAccounts);

    }

    @Test
    public void test_getFavoriteAccount() {

        FavoriteAccount favoriteAccount = FavoriteAccount.builder()
                .id(0L)
                .accountName("Test")
                .iban("Test")
                .bank("Test")
                .build();

        Mockito.when(repository.findById(0L)).thenReturn(Optional.of(favoriteAccount));

        assertThat(controller.getFavoriteAccount(0L)).isEqualTo(Optional.of(favoriteAccount));

    }

    @Test
    public void test_createFavoriteAccount() {

        FavoriteAccount favoriteAccount = FavoriteAccount.builder()
                .id(0L)
                .accountName("Test")
                .iban("Test")
                .bank("Test")
                .build();

        Mockito.when(repository.save(favoriteAccount)).thenReturn(favoriteAccount);

        assertThat(controller.createFavoriteAccount(favoriteAccount)).isEqualTo(favoriteAccount);

    }

    @Test
    public void test_editFavoriteAccount() {

        FavoriteAccount favoriteAccount = FavoriteAccount.builder()
                .id(0L)
                .accountName("Test")
                .iban("Test")
                .bank("Test")
                .build();

        Mockito.when(repository.save(favoriteAccount)).thenReturn(favoriteAccount);

        assertThat(controller.editFavoriteAccount(0L, favoriteAccount)).isEqualTo(favoriteAccount);

    }
}